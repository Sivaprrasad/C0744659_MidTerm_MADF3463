package com.lambton;

public class TestMain
{
    public static void main(String[] args)
    {
        System.out.println("~~~~~~REVERSE STRING~~~~");
        System.out.println("Reversed String : "+ LambtonStringTools.reverse("Lambton"));

        System.out.println("~~~~~BINARY TO DECIMAL~~~~");
        System.out.println(LambtonStringTools.binaryToDecimal());

        System.out.println("~~~~~MOST FREQUENT~~~~");
        String s = "sivaprrasad uppalapati";
        System.out.println("Most Frequent Character is " + LambtonStringTools.mostFrequent(s));

        // System.out.println("~~~~~REPLACE SUBSTRING~~~~");
        // System.out.println("~~~~~INITIALS~~~~");



    }
}
