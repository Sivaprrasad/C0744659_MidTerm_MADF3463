package com.lambton;
import java.util.*;

public class LambtonStringTools
{
    public static String reverse(String s)
    {
        int len = s.length();
        String temp = "";
        for(int i = len - 1; i >=0; i--)
        {
            temp += s.charAt(i);
        }

        return temp;
    }


    public static int binaryToDecimal()
    {
        Scanner s = new Scanner(System.in);

        System.out.println("Enter a binary number:");
        int n = s.nextInt();
        int decimal = 0,p = 0;

        while(n != 0)
        {
            decimal += ((n % 10) * Math.pow(2,p));
            n = n / 10;
            p++;
        }

        return decimal;
    }

    public static String initials(String s)
    {

        String fullName = "";
        fullName.charAt(0);


    }


    static final int ASCII_SIZE = 256;
    public static char mostFrequent(String s)
    {
        int count[] = new int[ASCII_SIZE];

        int len = s.length();
        for (int i = 0; i < len; i++)
            count[s.charAt(i)]++;

        int max = -1;
        char result = ' ';

        for (int i = 0; i < len; i++)
        {
            if (max < count[s.charAt(i)])
            {
                max = count[s.charAt(i)];
                result = s.charAt(i);
            }
        }

        return result;
    }

    public static String replaceSubString(String s1, String s2, String s3)
    {



    }


}
